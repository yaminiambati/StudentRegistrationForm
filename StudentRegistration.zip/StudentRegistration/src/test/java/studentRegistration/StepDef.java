package studentRegistration;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.PaymentDetailsBean;
import pages.PersonalDetailsBean;

public class StepDef {
	
	private WebDriver driver;
	private PersonalDetailsBean personalDetailsBean;
	private PaymentDetailsBean paymentDetailsBean;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","H:\\Spring\\chromedriver.exe");
		
		driver=new ChromeDriver();
		personalDetailsBean=new PersonalDetailsBean(driver);
		paymentDetailsBean= new PaymentDetailsBean(driver);
	}
	
	@Given("^valid personal details$")
	public void valid_personal_details() throws Throwable {
	  driver.get("http://localhost:8082/StudentRegistration/finishPayment");
	  //driver.get("http://localhost:8080/StudentRegistration/finishPayment");
	  personalDetailsBean.studentform("Yamini", "Ambati", "Jeedimetla", "Hyderabad", "Telangana", "female", "B.E", "9567898092");
	}

	@When("^valid payment details are submitted$")
	public void valid_payment_details_are_submitted() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Personal Details Successfully Entered!");
		driver.switchTo().alert().accept();
		paymentDetailsBean.setPaymentValues("YAMINI", "1234123412341216", "132", "July/21");
	}

	@Then("^payment successful$")
	public void payment_successful() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Payment Success!");
		driver.switchTo().alert().accept();
		driver.close();
	}
	
}
