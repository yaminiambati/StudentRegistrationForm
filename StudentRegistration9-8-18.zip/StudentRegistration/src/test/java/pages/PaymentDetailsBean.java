package pages;

import java.text.SimpleDateFormat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailsBean {

	@FindBy(name="holderName")
	private WebElement holderName;
	
	@FindBy(name="cardNo")
	private WebElement cardNo;
	
	@FindBy(name="cvvNo")
	private WebElement cvvNo;
	
	@FindBy(name="expiry")
	private WebElement expiry;
	
	@FindBy(id="confirmPay")
	private WebElement payButton;
	
	WebDriver driver;
	
	public PaymentDetailsBean(WebDriver driver1) {
		this.driver=driver1;
		PageFactory.initElements(driver, this);
	}
	
	public void setHolderName(String fname) {
		holderName.sendKeys(fname);
	}
	
	public void setcardNo(String lname) {
		cardNo.sendKeys(lname);
	}	
	
	public void setcvvNo(String add) {
		cvvNo.sendKeys(add);
	}
	
	public void setexpiry(String cit) {
		
		expiry.sendKeys(cit);
	}
	
	public void clickPay() {
		payButton.click();
	}
	
	public void setPaymentValues(String hName,String cNo,String cvvNo,String expDate) {
		
		this.setHolderName(hName);
		this.setcardNo(cNo);
		this.setcvvNo(cvvNo);
		this.setexpiry(expDate);
		this.clickPay();
		
	}
}
